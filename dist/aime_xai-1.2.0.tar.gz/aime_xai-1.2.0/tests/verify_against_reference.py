"""
Rigorous verification of aime_xai_new against:
  (1) the canonical reference implementation (uploaded core.py) — numerical equality,
  (2) first-principles mathematical properties of each variant,
  (3) reproducibility / determinism,
  (4) edge cases.
Runs entirely on numpy + matplotlib with lightweight stubs for sklearn/seaborn/umap.
"""
import os, sys, types, importlib.util
import numpy as np
import matplotlib
matplotlib.use("Agg")

PASS = 0; FAIL = 0; MSGS = []
def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1; print(f"  [PASS] {name}")
    else:
        FAIL += 1; print(f"  [FAIL] {name}  {extra}"); MSGS.append(name)

# --------------------------------------------------------------------------- #
# Stub external deps so BOTH implementations import in this sandbox.
# StandardScaler is a faithful (mean/std) implementation; PCA uses real SVD.
# --------------------------------------------------------------------------- #
def install_stubs():
    skl = types.ModuleType("sklearn")
    pre = types.ModuleType("sklearn.preprocessing")
    dec = types.ModuleType("sklearn.decomposition")
    man = types.ModuleType("sklearn.manifold")

    class StandardScaler:
        def fit(self, X):
            X = np.asarray(X, float); self.mean_ = X.mean(0)
            sd = X.std(0); sd[sd == 0] = 1.0; self.scale_ = sd; return self
        def transform(self, X): return (np.asarray(X, float) - self.mean_) / self.scale_
        def fit_transform(self, X): return self.fit(X).transform(X)
        def inverse_transform(self, X): return np.asarray(X, float) * self.scale_ + self.mean_

    class PCA:
        def __init__(self, n_components=2): self.k = n_components
        def fit_transform(self, X):
            X = np.asarray(X, float); self.mu = X.mean(0); Xc = X - self.mu
            U, S, Vt = np.linalg.svd(Xc, full_matrices=False); self.W = Vt[:self.k].T
            return Xc @ self.W
        def transform(self, X): return (np.asarray(X, float) - self.mu) @ self.W

    class TSNE:
        def __init__(self, n_components=2, **k): self.k = n_components
        def fit_transform(self, X):
            X = np.asarray(X, float); return X[:, :self.k] if X.shape[1] >= self.k else X

    pre.StandardScaler = StandardScaler; dec.PCA = PCA; man.TSNE = TSNE
    skl.preprocessing = pre; skl.decomposition = dec; skl.manifold = man
    sys.modules.update({"sklearn": skl, "sklearn.preprocessing": pre,
                        "sklearn.decomposition": dec, "sklearn.manifold": man})
    sns = types.ModuleType("seaborn")
    for fn in ("barplot", "heatmap", "kdeplot"):
        setattr(sns, fn, lambda *a, **k: None)
    sys.modules["seaborn"] = sns
    um = types.ModuleType("umap"); um2 = types.ModuleType("umap.umap_")
    class UMAP:
        def __init__(self, n_components=2, **k): self.k = n_components
        def fit_transform(self, X): return np.asarray(X, float)[:, :self.k]
        def transform(self, X): return np.asarray(X, float)[:, :self.k]
    um2.UMAP = UMAP; um.umap_ = um2
    sys.modules["umap"] = um; sys.modules["umap.umap_"] = um2

install_stubs()

# new implementation
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from aime_xai import AIME as NewAIME

# reference implementation (uploaded)
spec = importlib.util.spec_from_file_location("ref_core", os.environ.get("AIME_REFERENCE_CORE", os.path.join(os.path.dirname(__file__), "reference_core.py")))
ref = importlib.util.module_from_spec(spec); spec.loader.exec_module(ref)
RefAIME = ref.AIME

# --------------------------------------------------------------------------- #
# Datasets (fixed seeds)
# --------------------------------------------------------------------------- #
def make_data(seed, N, d, m, outliers=0):
    rng = np.random.default_rng(seed)
    X = rng.normal(0, 1, (N, d))
    if d >= 8:
        X[:, 4:8] = (X[:, 4:8] > 0.4).astype(float)   # some one-hot-ish columns
    W = rng.normal(0, 1, (d, m))
    logit = X @ W
    e = np.exp(logit - logit.max(1, keepdims=True)); Y = e / e.sum(1, keepdims=True)
    if outliers:
        X[:outliers] += rng.normal(0, 8, (outliers, d))
    return X, Y

DATASETS = {
    "binary_N400_d12":      make_data(0, 400, 12, 2),
    "binary_outliers":      make_data(1, 400, 12, 2, outliers=10),
    "threeclass_N500_d10":  make_data(2, 500, 10, 3),
    "fiveclass_N600_d16":   make_data(3, 600, 16, 5),
}

VARIANTS = {
    "AIME":            dict(),
    "HuberAIME":       dict(use_huber=True, delta=1.0, max_iter=80, tol=1e-7),
    "RidgeAIME":       dict(use_ridge=True, ridge_alpha=1.0),
    "Huber-RidgeAIME": dict(use_huber=True, use_ridge=True, ridge_alpha=1.0, max_iter=80, tol=1e-7),
    "BayesianAIME":    dict(use_bayesian=True, bayesian_sigma=1.0, bayesian_tau=1.0),
}

print("=" * 70)
print("1) NUMERICAL EQUALITY vs the canonical reference implementation")
print("=" * 70)
for dname, (X, Y) in DATASETS.items():
    for vname, kw in VARIANTS.items():
        new = NewAIME(**kw).create_explainer(X, Y, normalize=True)
        rf  = RefAIME(**kw).create_explainer(X, Y, normalize=True)
        check(f"{dname:22s} {vname:16s} A_dagger == reference",
              np.allclose(new.A_dagger, rf.A_dagger, atol=1e-9, rtol=1e-7),
              f"maxdiff={np.max(np.abs(new.A_dagger-rf.A_dagger)):.2e}")
        if kw.get("use_bayesian"):
            check(f"{dname:22s} {vname:16s} A_dagger_cov == reference",
                  np.allclose(new.A_dagger_cov, rf.A_dagger_cov, atol=1e-9),
                  f"maxdiff={np.max(np.abs(new.A_dagger_cov-rf.A_dagger_cov)):.2e}")

print()
print("=" * 70)
print("2) GLOBAL / LOCAL importance numerically match the reference")
print("=" * 70)
for dname, (X, Y) in DATASETS.items():
    d = X.shape[1]; feat = [f"f{i}" for i in range(d)]
    for vname, kw in VARIANTS.items():
        new = NewAIME(**kw).create_explainer(X, Y, normalize=True)
        rf  = RefAIME(**kw).create_explainer(X, Y, normalize=True)
        # global (normalised mean matrix)
        gnew = new.global_feature_importance_without_viz(feature_names=feat)
        gref = rf.global_feature_importance(feature_names=feat, with_plot=False)
        if kw.get("use_bayesian"):
            gref_mean = gref.xs("mean", axis=1, level=1)[gnew.columns]
        else:
            gref_mean = gref[gnew.columns]
        check(f"{dname:22s} {vname:16s} global importance == reference",
              np.allclose(gnew.values, gref_mean.values, atol=1e-9),
              f"maxdiff={np.max(np.abs(gnew.values-gref_mean.values)):.2e}")
        # local (single instance), masked + normalised
        x = X[5].copy(); x[3] = 0.0
        ynew = new.local_feature_importance_without_viz(
            x, Y[5], feature_names=feat, scaler=new.scaler, ignore_zero_features=True)
        yref = rf.local_feature_importance(
            x, Y[5], feature_names=feat, ignore_zero_features=True, with_plot=False)
        ref_mean = yref.loc["mean"] if "mean" in yref.index else yref.iloc[0]
        check(f"{dname:22s} {vname:16s} local importance == reference",
              np.allclose(ynew.iloc[0].values, ref_mean[ynew.columns].values, atol=1e-9),
              f"maxdiff={np.max(np.abs(ynew.iloc[0].values-ref_mean[ynew.columns].values)):.2e}")

print()
print("=" * 70)
print("3) BAYESIAN credible intervals match the reference (mean/lower/upper)")
print("=" * 70)
for dname, (X, Y) in DATASETS.items():
    d = X.shape[1]; feat = [f"f{i}" for i in range(d)]
    new = NewAIME(use_bayesian=True).create_explainer(X, Y, normalize=True)
    rf  = RefAIME(use_bayesian=True).create_explainer(X, Y, normalize=True)
    x = X[7].copy(); x[2] = 0.0
    lnew = new.local_feature_importance(x, Y[7], feature_names=feat, show=False)
    lref = rf.local_feature_importance(x, Y[7], feature_names=feat, with_plot=False)
    for row in ["mean", "lower_bound", "upper_bound"]:
        check(f"{dname:22s} Bayesian local {row:12s} == reference",
              np.allclose(lnew.loc[row].values, lref.loc[row][lnew.columns].values, atol=1e-9),
              f"maxdiff={np.max(np.abs(lnew.loc[row].values-lref.loc[row][lnew.columns].values)):.2e}")

print()
print("=" * 70)
print("4) FIRST-PRINCIPLES mathematical properties")
print("=" * 70)
X, Y = DATASETS["binary_N400_d12"]
sc_mu = X.mean(0); sc_sd = X.std(0); sc_sd[sc_sd == 0] = 1
Xp = (X - sc_mu) / sc_sd
Xt, Yt = Xp.T, Y.T   # (d,N),(m,N)

# AIME = least-squares minimiser:  A = X' pinv(Y')  ⇒ normal equations A (Y Yᵀ) = X Yᵀ
A = NewAIME().create_explainer(X, Y, normalize=True).A_dagger
check("AIME satisfies normal equations  A·(YYᵀ) = X'·Yᵀ",
      np.allclose(A @ (Yt @ Yt.T), Xt @ Yt.T, atol=1e-6),
      f"res={np.max(np.abs(A@(Yt@Yt.T)-Xt@Yt.T)):.2e}")

# Ridge:  A (YYᵀ + λI) = X' Yᵀ
lam = 2.5
Ar = NewAIME(use_ridge=True, ridge_alpha=lam).create_explainer(X, Y, normalize=True).A_dagger
check("RidgeAIME satisfies  A·(YYᵀ+λI) = X'·Yᵀ",
      np.allclose(Ar @ (Yt @ Yt.T + lam*np.eye(2)), Xt @ Yt.T, atol=1e-6),
      f"res={np.max(np.abs(Ar@(Yt@Yt.T+lam*np.eye(2))-Xt@Yt.T)):.2e}")
check("RidgeAIME(λ→0) → AIME",
      np.allclose(NewAIME(use_ridge=True, ridge_alpha=1e-9).create_explainer(X, Y, normalize=True).A_dagger,
                  A, atol=1e-5))

# Bayesian:  cov · precision = I ;  posterior mean formula ;  τ→∞ ⇒ AIME
b = NewAIME(use_bayesian=True, bayesian_sigma=1.3, bayesian_tau=0.7).create_explainer(X, Y, normalize=True)
s2i, t2i = 1/1.3**2, 1/0.7**2
prec = s2i*(Y.T@Y) + t2i*np.eye(2)
check("Bayesian posterior cov is the inverse of the precision matrix",
      np.allclose(b.A_dagger_cov @ prec, np.eye(2), atol=1e-8))
A_prior = Xt @ np.linalg.pinv(Yt)
mean_chk = (b.A_dagger_cov @ (s2i*(Y.T@Xp) + t2i*A_prior.T)).T
check("Bayesian posterior mean matches closed form",
      np.allclose(b.A_dagger, mean_chk, atol=1e-9))
b_weakprior = NewAIME(use_bayesian=True, bayesian_sigma=1.0, bayesian_tau=1e6).create_explainer(X, Y, normalize=True)
check("BayesianAIME(τ→∞, weak prior) → AIME pseudo-inverse",
      np.allclose(b_weakprior.A_dagger, A, atol=1e-4),
      f"maxdiff={np.max(np.abs(b_weakprior.A_dagger-A)):.2e}")

# Huber: robust objective is not larger than OLS on outlier data; weights ∈ (0,1]
Xo, Yo = DATASETS["binary_outliers"]
Xpo = (Xo - Xo.mean(0)) / np.where(Xo.std(0) == 0, 1, Xo.std(0))
Xto, Yto = Xpo.T, Yo.T
A_ols = NewAIME().create_explainer(Xo, Yo, normalize=True).A_dagger
A_hub = NewAIME(use_huber=True, delta=1.0, max_iter=100, tol=1e-9).create_explainer(Xo, Yo, normalize=True).A_dagger
def huber_obj(M, delta=1.0):
    r = np.linalg.norm(Xto - M @ Yto, axis=0)
    return np.where(r <= delta, 0.5*r**2, delta*(r - 0.5*delta)).sum()
check("HuberAIME lowers the Huber objective vs OLS on outlier data",
      huber_obj(A_hub) <= huber_obj(A_ols) + 1e-9,
      f"huber={huber_obj(A_hub):.3f} ols={huber_obj(A_ols):.3f}")
check("HuberAIME differs from AIME when outliers are present",
      not np.allclose(A_hub, A_ols, atol=1e-3))

# rbf_kernel matches definition
e = NewAIME().create_explainer(X, Y, normalize=True)
v1 = np.random.default_rng(9).normal(size=(5, 12)); v2 = np.random.default_rng(8).normal(size=(2, 12))
K = e.rbf_kernel(v1, v2, 0.3)
Kref = np.exp(-0.3*((v1[:, None, :]-v2[None, :, :])**2).sum(-1))
check("rbf_kernel == exp(-γ‖·‖²)", np.allclose(K, Kref, atol=1e-10))

# representative_instance == inverse_transform(A e_t)
rep = e.representative_instance(scaler=e.scaler)
ok = all(np.allclose(rep.iloc[t].values, e.scaler.inverse_transform(e.A_dagger @ np.eye(2)[t]), atol=1e-9)
         for t in range(2))
check("representative_instance == scaler⁻¹(A·eₜ)", ok)

# local Hadamard rule + exact zero on absent feature
x = X[10].copy(); x[6] = 0.0
loc = e.local_feature_importance_without_viz(x, Y[10], scaler=e.scaler, ignore_zero_features=True)
xp = e.scaler.transform([x])[0]; ref_loc = (e.A_dagger @ Y[10]) * xp * (x != 0)
ref_loc = ref_loc / np.max(np.abs(ref_loc))
check("local importance == (A·y)⊙x'  (Hadamard rule)", np.allclose(loc.iloc[0].values, ref_loc, atol=1e-9))
check("absent feature (x=0) gets exactly zero importance", loc.iloc[0].values[6] == 0.0)

print()
print("=" * 70)
print("5) REPRODUCIBILITY / DETERMINISM")
print("=" * 70)
for vname, kw in VARIANTS.items():
    a1 = NewAIME(**kw).create_explainer(X, Y, normalize=True).A_dagger
    a2 = NewAIME(**kw).create_explainer(X, Y, normalize=True).A_dagger
    check(f"{vname:16s} is deterministic (identical on re-fit)", np.array_equal(a1, a2))

print()
print("=" * 70)
print("6) VIZ methods do not alter returned numbers; edge cases")
print("=" * 70)
# viz vs no-viz return identical numbers
g_viz = NewAIME().create_explainer(X, Y, normalize=True).global_feature_importance(show=False)
g_now = NewAIME().create_explainer(X, Y, normalize=True).global_feature_importance_without_viz()
check("global_feature_importance(show=False) == without_viz", np.allclose(g_viz.values, g_now.values, atol=1e-12))
# normalize=False path
en = NewAIME().create_explainer(X, Y, normalize=False)
check("normalize=False fits (scaler is None, A_dagger finite)",
      en.scaler is None and np.all(np.isfinite(en.A_dagger)))
check("normalize=False: A_dagger = X pinv(Yᵀ) (raw)",
      np.allclose(en.A_dagger, X.T @ np.linalg.pinv(Y.T), atol=1e-9))
# three-class shapes
e3 = NewAIME().create_explainer(*DATASETS["threeclass_N500_d10"], normalize=True)
check("multiclass A_dagger shape (d, m)", e3.A_dagger.shape == (10, 3))

print()
print("=" * 70)
print(f"RESULT:  {PASS} passed, {FAIL} failed")
if FAIL:
    print("FAILURES:", MSGS)
print("=" * 70)
sys.exit(1 if FAIL else 0)
