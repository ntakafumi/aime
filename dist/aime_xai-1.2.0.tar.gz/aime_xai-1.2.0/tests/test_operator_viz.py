"""
Closed-form correctness tests for aime_xai.operator_viz.OperatorVisualizer.

Every quantity is checked against its definition, and the evaluator is checked to
never mutate the fitted operator (the AIME-family derivation is untouched).
Run with:  pytest -q
"""
import numpy as np
import pytest

from aime_xai import AIME, OperatorVisualizer


def make(seed=0, N=300, d=10, m=3):
    rng = np.random.default_rng(seed)
    X = rng.normal(0, 1, (N, d))
    if d >= 8:
        X[:, 4:8] = (X[:, 4:8] > 0.4).astype(float)
    W = rng.normal(size=(d, m))
    lo = X @ W
    e = np.exp(lo - lo.max(1, keepdims=True))
    Y = e / e.sum(1, keepdims=True)
    return X, Y


def viz(seed=0, **kw):
    X, Y = make(seed)
    e = AIME(**kw).create_explainer(X, Y, normalize=True)
    return e, OperatorVisualizer(e, X, Y), X, Y


def test_visualizer_does_not_mutate_operator():
    e, v, X, Y = viz()
    A0 = e.A_dagger.copy()
    v.plot_operator_map(show=False)
    v.plot_explanation_redundancy(show=False)
    v.plot_inverse_modes(show=False)
    assert np.array_equal(A0, e.A_dagger)


def test_operator_map_is_A():
    e, v, X, Y = viz()
    df = v.plot_operator_map(show=False)
    assert np.allclose(df.values, e.A_dagger, atol=1e-12)


def test_class_contrast_definition():
    e, v, X, Y = viz()
    c = v.plot_class_contrast(0, 1, show=False)
    assert np.allclose(c.values, e.A_dagger[:, 0] - e.A_dagger[:, 1], atol=1e-12)


def test_prototype_is_inverse_transform_of_columns():
    e, v, X, Y = viz()
    proto = v.prototypes()
    for k in range(e.A_dagger.shape[1]):
        assert np.allclose(proto.iloc[k].values,
                           e.scaler.inverse_transform(e.A_dagger[:, k][None, :])[0], atol=1e-9)


def test_counterfactual_direction_definition():
    e, v, X, Y = viz()
    m = e.A_dagger.shape[1]
    d = v.plot_counterfactual_direction(X[3], Y[3], target=2, show=False)
    ref = e.A_dagger @ (np.eye(m)[2] - Y[3])
    assert np.allclose(d.values, ref, atol=1e-12)


def test_inverse_deviation_definition():
    e, v, X, Y = viz()
    R, rn = v.inverse_deviation()
    Xp = e.scaler.transform(X)
    assert np.allclose(R, Xp - Y @ e.A_dagger.T, atol=1e-12)
    assert np.allclose(rn, np.linalg.norm(R, axis=1), atol=1e-12)


def test_reliability_weights_definition():
    e, v, X, Y = viz(use_huber=True, delta=1.0)
    w, delta = v.reliability_weights()
    _, rn = v.inverse_deviation()
    ref = np.minimum(1.0, delta / rn)
    assert np.allclose(w, ref, atol=1e-12)
    assert np.all((w > 0) & (w <= 1 + 1e-12))


def test_redundancy_is_cosine_of_rows():
    e, v, X, Y = viz()
    Sm = v.redundancy_matrix()
    A = e.A_dagger
    nrm = np.linalg.norm(A, axis=1, keepdims=True)
    Au = A / np.where(nrm == 0, 1, nrm)
    assert np.allclose(Sm, Au @ Au.T, atol=1e-12)
    assert np.allclose(np.diag(Sm), 1.0, atol=1e-9)        # self-similarity = 1


def test_inverse_modes_reconstruct_A():
    e, v, X, Y = viz()
    U, Sg, Vt = v.inverse_modes()
    assert np.allclose(U @ np.diag(Sg) @ Vt, e.A_dagger, atol=1e-9)


def test_uncertainty_requires_bayesian():
    e, v, X, Y = viz()                       # plain AIME → no covariance
    with pytest.raises(ValueError):
        v.plot_uncertainty_map(show=False)
    eb, vb, X, Y = viz(use_bayesian=True)
    snr = vb.plot_uncertainty_map(show=False)
    assert snr.shape == (10, 3) and np.all(np.isfinite(snr.values))
