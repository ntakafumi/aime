"""
Reproducible correctness tests for aime_xai.metrics.

Run with:  pytest -q   (from src/aime_xai_new)

Pins each inverse-explanation metric to closed-form / known answers and checks
that computing metrics never mutates the fitted operator.
"""
import numpy as np
import pytest

from aime_xai import AIME, AIMEEvaluator
import aime_xai.metrics as M


def make(seed=0, N=400, d=12, m=2):
    rng = np.random.default_rng(seed)
    X = rng.normal(0, 1, (N, d))
    if d >= 8:
        X[:, 4:8] = (X[:, 4:8] > 0.4).astype(float)
    W = rng.normal(size=(d, m))
    lo = X @ W
    e = np.exp(lo - lo.max(1, keepdims=True))
    Y = e / e.sum(1, keepdims=True)
    return X, Y


# ---- pure functions ------------------------------------------------------- #
def test_reconstruct_definition():
    rng = np.random.default_rng(0)
    A = rng.normal(size=(6, 3)); Y = rng.random((50, 3))
    assert np.allclose(M.reconstruct(A, Y), Y @ A.T)


def test_ire_zero_and_irr_one_on_perfect_inverse():
    rng = np.random.default_rng(0)
    Y = rng.random((300, 3)); Y /= Y.sum(1, keepdims=True)   # rows sum to 1
    Mtrue = rng.normal(size=(6, 3))
    Xp = Y @ Mtrue.T                                         # in row space of Yᵀ
    A = Xp.T @ np.linalg.pinv(Y.T)
    Xhat = M.reconstruct(A, Y)
    assert abs(M.ire(Xp, A, Y)) < 1e-9
    assert abs(M.variance_recovery_rate(Xhat, Xp) - 1.0) < 1e-9


def test_irr_is_variance_ratio_and_decoupled_from_ire():
    rng = np.random.default_rng(1)
    # unequal feature variances so IRR (variance-weighted) != 1 - IRE^2
    X = rng.normal(size=(300, 6)) * np.array([5, 5, 1, 1, 0.2, 0.2])
    A = rng.normal(size=(6, 3))
    Y = rng.random((300, 3)); Y /= Y.sum(1, keepdims=True)
    Xhat = M.reconstruct(A, Y)
    irr = M.variance_recovery_rate(Xhat, X)
    assert abs(irr - Xhat.var(0).sum() / X.var(0).sum()) < 1e-12   # definition
    assert 0 - 1e-9 <= irr <= 1 + 1e-9                              # bounded
    assert abs(irr - (1 - M.ire(X, A, Y) ** 2)) > 1e-3             # decoupled from IRE
    assert M.ire(X, A, Y) >= 0


def test_coverage_bounds():
    n, m = 6, 3
    assert np.allclose(M.coverage(np.ones((n, m))), 1.0)        # all equal -> 1
    onehot = np.zeros((n, m)); onehot[0, :] = 1.0
    assert np.allclose(M.coverage(onehot), 1.0 / n)            # one feature -> 1/n
    rng = np.random.default_rng(0)
    ec = M.coverage(rng.normal(size=(n, m)))
    assert np.all(ec >= 1 / n - 1e-9) and np.all(ec <= 1 + 1e-9)


def test_effective_rank_limits():
    rng = np.random.default_rng(0)
    u = rng.normal(size=(6, 1)); v = rng.normal(size=(1, 3))
    r1 = M.effective_rank(u @ v)
    assert r1["rank"] == 1 and abs(r1["effective_rank"] - 1) < 1e-6
    k = 3
    Q1, _ = np.linalg.qr(rng.normal(size=(6, k))); Q2, _ = np.linalg.qr(rng.normal(size=(3, k)))
    re = M.effective_rank(Q1 @ np.eye(k) @ Q2.T)
    assert abs(re["effective_rank"] - k) < 1e-6


def test_class_separability_extremes():
    rng = np.random.default_rng(0)
    labels = rng.integers(0, 3, 300)
    L_same = np.tile(rng.normal(size=(1, 5)), (300, 1))
    assert M.class_separability(L_same, labels) == 0.0           # identical -> 0
    L_sep = np.zeros((300, 5))
    for c in range(3):
        L_sep[labels == c] = (c + 1)
    assert np.isinf(M.class_separability(L_sep, labels)) or M.class_separability(L_sep, labels) > 1e6


def test_lgc_bounds():
    rng = np.random.default_rng(0)
    A = rng.normal(size=(8, 3)); Y = rng.random((200, 3)); Y /= Y.sum(1, keepdims=True)
    Xp = rng.normal(size=(200, 8))
    lg = M.local_global_consistency(A, M.reconstruct(A, Y) * Xp, np.argmax(Y, 1))
    fin = lg["per_class"][np.isfinite(lg["per_class"])]
    assert np.all(np.abs(fin) <= 1 + 1e-9)


# ---- evaluator end-to-end ------------------------------------------------- #
VARIANTS = [dict(), dict(use_huber=True), dict(use_ridge=True, ridge_alpha=1.0),
            dict(use_huber=True, use_ridge=True), dict(use_bayesian=True)]


@pytest.mark.parametrize("kw", VARIANTS)
def test_evaluator_ranges_and_core_untouched(kw):
    X, Y = make(0)
    e = AIME(**kw).create_explainer(X, Y, normalize=True)
    A_before = e.A_dagger.copy()
    ev = AIMEEvaluator(e, X, Y, feature_names=[f"f{i}" for i in range(12)], class_names=["a", "b"])
    s = ev.summary()
    assert np.array_equal(A_before, e.A_dagger)            # metrics never mutate the operator
    assert -1e-9 <= s["IRR"] <= 1 + 1e-9                    # variance recovery, bounded
    assert s["IRE"] >= 0
    assert 0 <= s["RIC"] <= 1 and 0 <= s["RIC_purity"] <= 1
    assert 1 / 12 - 1e-9 <= s["EC"] <= 1 + 1e-9
    assert -1 - 1e-9 <= s["LGC"] <= 1 + 1e-9
    assert s["CSI"] >= 0
    assert 1 <= s["rank"] <= 2 and 1 - 1e-9 <= s["effective_rank"] <= s["rank"] + 1e-9
    assert 0 <= s["IES"] <= 1


def test_ies_is_core_only():
    X, Y = make(0)
    e = AIME().create_explainer(X, Y, normalize=True)
    ev = AIMEEvaluator(e, X, Y)
    ies = ev.inverse_explainability_score()
    comps, w = ies["components"], ies["weights"]
    # exactly the six core axes — no IRE / IRR
    assert set(comps) == {"Consistency (LGC)", "Stability (RIC)", "Stability (purity)",
                          "Coverage (EC)", "Separability (CSI)", "Simplicity (rank)"}
    assert abs(ies["score"] - sum(w[k] * comps[k] for k in comps)) < 1e-12
    assert 0 <= ies["score"] <= 1
    assert M.METRIC_TIER["IES"][0] == M.TIER_CORE


def test_metrics_deterministic():
    X, Y = make(0)
    e = AIME().create_explainer(X, Y, normalize=True)
    s1 = AIMEEvaluator(e, X, Y).summary()
    s2 = AIMEEvaluator(e, X, Y).summary()
    assert all(np.allclose(s1[k], s2[k]) for k in s1)
