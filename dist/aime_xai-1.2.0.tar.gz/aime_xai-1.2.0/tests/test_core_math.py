"""
Reproducible correctness tests for the AIME family (aime_xai).

Run with:  pytest -q   (from src/aime_xai_new)

These tests pin the *mathematics* of every variant to first principles, so any
future change that silently alters the operator will be caught.  They use real
scikit-learn StandardScaler and require only numpy/pandas/scikit-learn.
"""
import numpy as np
import pytest

from aime_xai import AIME


# --------------------------------------------------------------------------- #
# Fixtures / helpers
# --------------------------------------------------------------------------- #
def make_data(seed=0, N=400, d=12, m=2, outliers=0):
    rng = np.random.default_rng(seed)
    X = rng.normal(0, 1, (N, d))
    if d >= 8:
        X[:, 4:8] = (X[:, 4:8] > 0.4).astype(float)
    W = rng.normal(0, 1, (d, m))
    logit = X @ W
    e = np.exp(logit - logit.max(1, keepdims=True))
    Y = e / e.sum(1, keepdims=True)
    if outliers:
        X[:outliers] += rng.normal(0, 8, (outliers, d))
    return X, Y


def scaled(X):
    mu = X.mean(0); sd = X.std(0); sd[sd == 0] = 1.0
    return (X - mu) / sd, mu, sd


VARIANTS = {
    "AIME": dict(),
    "HuberAIME": dict(use_huber=True, delta=1.0, max_iter=80, tol=1e-8),
    "RidgeAIME": dict(use_ridge=True, ridge_alpha=1.0),
    "Huber-RidgeAIME": dict(use_huber=True, use_ridge=True, ridge_alpha=1.0, max_iter=80, tol=1e-8),
    "BayesianAIME": dict(use_bayesian=True, bayesian_sigma=1.0, bayesian_tau=1.0),
}


# --------------------------------------------------------------------------- #
# Shapes & variant naming
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("m", [2, 3, 5])
def test_operator_shape(m):
    X, Y = make_data(m, d=10, m=m)
    e = AIME().create_explainer(X, Y, normalize=True)
    assert e.A_dagger.shape == (10, m)


def test_variant_names():
    assert AIME().variant_name == "AIME"
    assert AIME(use_huber=True).variant_name == "HuberAIME"
    assert AIME(use_ridge=True).variant_name == "RidgeAIME"
    assert AIME(use_huber=True, use_ridge=True).variant_name == "Huber-RidgeAIME"
    assert AIME(use_bayesian=True).variant_name == "BayesianAIME"


def test_bayesian_excludes_huber_ridge():
    with pytest.raises(ValueError):
        AIME(use_bayesian=True, use_huber=True)
    with pytest.raises(ValueError):
        AIME(use_bayesian=True, use_ridge=True)


# --------------------------------------------------------------------------- #
# First-principles operator equations
# --------------------------------------------------------------------------- #
def test_aime_normal_equations():
    X, Y = make_data(0)
    Xp, _, _ = scaled(X); Xt, Yt = Xp.T, Y.T
    A = AIME().create_explainer(X, Y, normalize=True).A_dagger
    # least-squares solution ⇒ A (Y Yᵀ) = X' Yᵀ
    assert np.allclose(A @ (Yt @ Yt.T), Xt @ Yt.T, atol=1e-6)


def test_aime_equals_pseudo_inverse_no_norm():
    X, Y = make_data(1)
    A = AIME().create_explainer(X, Y, normalize=False).A_dagger
    assert np.allclose(A, X.T @ np.linalg.pinv(Y.T), atol=1e-9)


@pytest.mark.parametrize("lam", [0.5, 2.5, 10.0])
def test_ridge_normal_equations(lam):
    X, Y = make_data(0); m = Y.shape[1]
    Xp, _, _ = scaled(X); Xt, Yt = Xp.T, Y.T
    A = AIME(use_ridge=True, ridge_alpha=lam).create_explainer(X, Y, normalize=True).A_dagger
    assert np.allclose(A @ (Yt @ Yt.T + lam*np.eye(m)), Xt @ Yt.T, atol=1e-6)


def test_ridge_limit_to_aime():
    X, Y = make_data(2)
    a0 = AIME().create_explainer(X, Y, normalize=True).A_dagger
    ar = AIME(use_ridge=True, ridge_alpha=1e-9).create_explainer(X, Y, normalize=True).A_dagger
    assert np.allclose(a0, ar, atol=1e-5)


def test_bayesian_posterior_formulas():
    X, Y = make_data(0); m = Y.shape[1]
    Xp, _, _ = scaled(X)
    sigma, tau = 1.3, 0.7
    b = AIME(use_bayesian=True, bayesian_sigma=sigma, bayesian_tau=tau).create_explainer(
        X, Y, normalize=True)
    s2i, t2i = 1/sigma**2, 1/tau**2
    prec = s2i*(Y.T @ Y) + t2i*np.eye(m)
    # covariance is the inverse precision
    assert np.allclose(b.A_dagger_cov @ prec, np.eye(m), atol=1e-8)
    # posterior mean closed form
    A_prior = Xp.T @ np.linalg.pinv(Y.T)
    mean = (b.A_dagger_cov @ (s2i*(Y.T @ Xp) + t2i*A_prior.T)).T
    assert np.allclose(b.A_dagger, mean, atol=1e-9)


def test_bayesian_weak_prior_to_aime():
    X, Y = make_data(3)
    a0 = AIME().create_explainer(X, Y, normalize=True).A_dagger
    b = AIME(use_bayesian=True, bayesian_sigma=1.0, bayesian_tau=1e6).create_explainer(
        X, Y, normalize=True).A_dagger
    assert np.allclose(a0, b, atol=1e-4)


def test_huber_reduces_objective_with_outliers():
    X, Y = make_data(1, outliers=10)
    Xp, _, _ = scaled(X); Xt, Yt = Xp.T, Y.T
    a_ols = AIME().create_explainer(X, Y, normalize=True).A_dagger
    a_hub = AIME(use_huber=True, delta=1.0, max_iter=100, tol=1e-9).create_explainer(
        X, Y, normalize=True).A_dagger

    def hobj(M, delta=1.0):
        r = np.linalg.norm(Xt - M @ Yt, axis=0)
        return np.where(r <= delta, 0.5*r**2, delta*(r - 0.5*delta)).sum()

    assert hobj(a_hub) <= hobj(a_ols) + 1e-9
    assert not np.allclose(a_hub, a_ols, atol=1e-3)   # outliers actually change it


# --------------------------------------------------------------------------- #
# Importance rules
# --------------------------------------------------------------------------- #
def test_global_is_normalized_columns():
    X, Y = make_data(0)
    e = AIME().create_explainer(X, Y, normalize=True)
    g = e.global_feature_importance_without_viz()
    for t in range(Y.shape[1]):
        col = e.A_dagger @ np.eye(Y.shape[1])[t]
        col = col / np.max(np.abs(col))
        assert np.allclose(g.iloc[t].values, col, atol=1e-9)


def test_local_hadamard_rule_and_zero_feature():
    X, Y = make_data(0)
    e = AIME().create_explainer(X, Y, normalize=True)
    x = X[10].copy(); x[6] = 0.0
    loc = e.local_feature_importance_without_viz(
        x, Y[10], scaler=e.scaler, ignore_zero_features=True)
    xp = e.scaler.transform([x])[0]
    ref = (e.A_dagger @ Y[10]) * xp * (x != 0)
    ref = ref / np.max(np.abs(ref))
    assert np.allclose(loc.iloc[0].values, ref, atol=1e-9)
    assert loc.iloc[0].values[6] == 0.0          # absent feature → exactly 0


def test_representative_instance():
    X, Y = make_data(0)
    e = AIME().create_explainer(X, Y, normalize=True)
    rep = e.representative_instance(scaler=e.scaler)
    for t in range(Y.shape[1]):
        assert np.allclose(rep.iloc[t].values,
                           e.scaler.inverse_transform(e.A_dagger @ np.eye(Y.shape[1])[t]),
                           atol=1e-9)


def test_rbf_kernel_definition():
    X, Y = make_data(0)
    e = AIME().create_explainer(X, Y, normalize=True)
    v1 = np.random.default_rng(9).normal(size=(5, X.shape[1]))
    v2 = np.random.default_rng(8).normal(size=(2, X.shape[1]))
    K = e.rbf_kernel(v1, v2, 0.3)
    ref = np.exp(-0.3*((v1[:, None, :]-v2[None, :, :])**2).sum(-1))
    assert np.allclose(K, ref, atol=1e-10)


def test_bayesian_local_intervals_contain_mean():
    X, Y = make_data(0)
    e = AIME(use_bayesian=True).create_explainer(X, Y, normalize=True)
    x = X[7].copy(); x[2] = 0.0
    df = e.local_feature_importance(x, Y[7], show=False)
    assert set(df.index) == {"mean", "lower_bound", "upper_bound"}
    assert np.all(df.loc["lower_bound"].values <= df.loc["mean"].values + 1e-12)
    assert np.all(df.loc["upper_bound"].values >= df.loc["mean"].values - 1e-12)


# --------------------------------------------------------------------------- #
# Reproducibility & viz invariance
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("name,kw", list(VARIANTS.items()))
def test_deterministic(name, kw):
    X, Y = make_data(0)
    a1 = AIME(**kw).create_explainer(X, Y, normalize=True).A_dagger
    a2 = AIME(**kw).create_explainer(X, Y, normalize=True).A_dagger
    assert np.array_equal(a1, a2)


def test_viz_does_not_change_numbers():
    import matplotlib
    matplotlib.use("Agg")
    X, Y = make_data(0)
    g_viz = AIME().create_explainer(X, Y, normalize=True).global_feature_importance(show=False)
    g_now = AIME().create_explainer(X, Y, normalize=True).global_feature_importance_without_viz()
    assert np.allclose(g_viz.values, g_now.values, atol=1e-12)
