"""
Paper-fidelity verification for ``aime_xai_new``.

Two complementary checks, run over several datasets and all 5 AIME-family
variants:

  (A) REFERENCE EQUIVALENCE
      aime_xai_new reproduces the canonical published reference implementation
      (``src/bayesian_aime/aime_xai/core.py``, the 5-variant reference) for the
      inverse operator ``A†`` and, for BayesianAIME, the posterior covariance.

  (B) CLOSED-FORM PAPER FIDELITY
      aime_xai_new's quantities match the equations stated in the AIME papers,
      re-derived here independently from numpy primitives:
        AIME        A† = X'ᵀ · pinv(Yᵀ)
        RidgeAIME   A† = X'ᵀ Y (YᵀY + λI)⁻¹      [= X_t Y_tᵀ(Y_tY_tᵀ+λI)⁻¹]
        HuberAIME   IRLS, wᵢ = min(1, δ/‖rᵢ‖)
        BayesianAIME  Σ=(σ⁻²YᵀY+τ⁻²I)⁻¹,  μ=Σ(σ⁻²YᵀX'+τ⁻²Â_priorᵀ)
        Global FI   column t of A†, peak-normalised
        Local  FI   (A†y) ⊙ x', (optionally) zero-masked, peak-normalised
        Rep. inst.  scaler⁻¹(A† eₜ)
        RBF sim.    exp(-γ‖·‖²)

The AIME-family DERIVATION is never modified by this test; it only reads the
fitted operators.  Tolerances are exact (atol=1e-9) for operator-level and
closed-form identities.

Runs under pytest, or standalone: ``python test_paper_fidelity.py``.
In a minimal sandbox (no scikit-learn/seaborn/umap) lightweight shims are
injected so the reference module imports; in a normal environment the real
libraries are used.
"""
from __future__ import annotations
import os, sys, types, importlib.util
import numpy as np

# --------------------------------------------------------------------------- #
# 0. Make both packages importable, shimming heavy deps only if missing.       #
# --------------------------------------------------------------------------- #
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.abspath(os.path.join(HERE, "..", ".."))          # .../src
NEW_PKG = os.path.join(SRC, "aime_xai_new")
REF_CORE = os.path.join(SRC, "bayesian_aime", "aime_xai", "core.py")


def _ensure_deps():
    """Inject minimal shims for sklearn/seaborn/umap when they are absent so the
    reference module (which imports them at top level) can load.  StandardScaler
    is a real, exact implementation; the rest are unused dummies."""
    try:
        import sklearn.preprocessing  # noqa: F401
        return
    except Exception:
        pass
    skl = types.ModuleType("sklearn")
    pre = types.ModuleType("sklearn.preprocessing")
    dec = types.ModuleType("sklearn.decomposition")
    man = types.ModuleType("sklearn.manifold")

    class StandardScaler:
        def fit(self, X):
            X = np.asarray(X, float)
            self.mean_ = X.mean(0)
            sd = X.std(0); sd[sd == 0] = 1.0
            self.scale_ = sd
            return self
        def transform(self, X):
            return (np.asarray(X, float) - self.mean_) / self.scale_
        def fit_transform(self, X):
            return self.fit(X).transform(X)
        def inverse_transform(self, X):
            return np.asarray(X, float) * self.scale_ + self.mean_

    class _Dummy:
        def __init__(self, *a, **k): ...
        def fit_transform(self, X): return np.asarray(X, float)
        def transform(self, X): return np.asarray(X, float)

    pre.StandardScaler = StandardScaler
    dec.PCA = _Dummy
    man.TSNE = _Dummy
    skl.preprocessing = pre; skl.decomposition = dec; skl.manifold = man
    sys.modules["sklearn"] = skl
    sys.modules["sklearn.preprocessing"] = pre
    sys.modules["sklearn.decomposition"] = dec
    sys.modules["sklearn.manifold"] = man
    # umap.umap_  and  seaborn
    umap = types.ModuleType("umap"); umap_ = types.ModuleType("umap.umap_")
    umap_.UMAP = _Dummy; umap.umap_ = umap_
    sys.modules["umap"] = umap; sys.modules["umap.umap_"] = umap_
    sns = types.ModuleType("seaborn")
    for fn in ("barplot", "heatmap", "kdeplot", "scatterplot"):
        setattr(sns, fn, lambda *a, **k: None)
    sys.modules["seaborn"] = sns
    import matplotlib
    matplotlib.use("Agg")


_ensure_deps()

# new package (relative imports inside -> import as a real package)
if NEW_PKG not in sys.path:
    sys.path.insert(0, NEW_PKG)
import aime_xai as NEW                      # noqa: E402
NewAIME = NEW.AIME

# reference core (self-contained, no relative imports) -> load by file path
_spec = importlib.util.spec_from_file_location("ref_aime_core", REF_CORE)
ref_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ref_mod)
RefAIME = ref_mod.AIME


# --------------------------------------------------------------------------- #
# 1. Datasets (deterministic).                                                 #
# --------------------------------------------------------------------------- #
def _softmax(Z):
    e = np.exp(Z - Z.max(1, keepdims=True))
    return e / e.sum(1, keepdims=True)


def datasets():
    rng = np.random.default_rng(20240613)
    out = {}
    # multiclass tabular with one-hot block
    X = rng.normal(size=(400, 12)); X[:, 6:] = (X[:, 6:] > 0.3).astype(float)
    out["multiclass(3)"] = (X, _softmax(X @ rng.normal(size=(12, 3))))
    # binary
    Xb = rng.normal(size=(300, 8))
    out["binary(2)"] = (Xb, _softmax(Xb @ rng.normal(size=(8, 2))))
    # outlier-contaminated (stresses Huber)
    Xo = rng.normal(size=(350, 10)); Xo[:20] *= 12.0
    out["outliers(4)"] = (Xo, _softmax(Xo @ rng.normal(size=(10, 4))))
    # wide / image-like
    Xi = rng.normal(size=(250, 64))
    out["image-like(5)"] = (Xi, _softmax(Xi @ rng.normal(size=(64, 5))))
    return out


VARIANTS = {
    "AIME":            dict(),
    "HuberAIME":       dict(use_huber=True, delta=1.0),
    "RidgeAIME":       dict(use_ridge=True, ridge_alpha=1e-3),
    "Huber-RidgeAIME": dict(use_huber=True, use_ridge=True, ridge_alpha=1e-3),
    "BayesianAIME":    dict(use_bayesian=True),
}

ATOL = 1e-9
_results = []  # (check_name, passed, detail)


def _chk(name, cond, detail=""):
    _results.append((name, bool(cond), detail))
    return bool(cond)


# --------------------------------------------------------------------------- #
# 2. Independent closed-form re-derivations straight from the paper formulae.  #
# --------------------------------------------------------------------------- #
def paper_operator(kind, Xp, Y, delta=1.0, lam=1e-3, sigma=1.0, tau=1.0,
                   max_iter=50, tol=1e-5):
    Xt, Yt = Xp.T, Y.T                       # (n,N), (m,N)
    if kind == "AIME":
        return Xt @ np.linalg.pinv(Yt)
    if kind == "RidgeAIME":
        m = Yt.shape[0]
        return Xt @ (Yt.T @ np.linalg.inv(Yt @ Yt.T + lam * np.eye(m)))
    if kind in ("HuberAIME", "Huber-RidgeAIME"):
        ridge = (kind == "Huber-RidgeAIME")
        m = Yt.shape[0]
        lamI = lam * np.eye(m) if ridge else 0.0
        M = Xt @ (Yt.T @ np.linalg.inv(Yt @ Yt.T + lamI))
        for _ in range(max_iter):
            R = Xt - M @ Yt
            rn = np.linalg.norm(R, axis=0)
            w = np.where(rn > delta, delta / rn, 1.0)
            sw = np.sqrt(w)
            Xw, Yw = Xt * sw, Yt * sw
            M_new = Xw @ (Yw.T @ np.linalg.inv(Yw @ Yw.T + lamI))
            if np.linalg.norm(M_new - M, ord="fro") < tol:   # break-before-assign
                break
            M = M_new
        return M
    if kind == "BayesianAIME":
        N, d = Xp.shape; m = Y.shape[1]
        s2i, t2i = 1 / sigma**2, 1 / tau**2
        A_prior = Xp.T @ np.linalg.pinv(Y.T)
        Sig = np.linalg.inv(s2i * (Y.T @ Y) + t2i * np.eye(m))
        mean_T = Sig @ (s2i * (Y.T @ Xp) + t2i * A_prior.T)
        return mean_T.T, Sig
    raise ValueError(kind)


# --------------------------------------------------------------------------- #
# 3. The actual checks.                                                        #
# --------------------------------------------------------------------------- #
def run():
    for dname, (X, Y) in datasets().items():
        for vname, kw in VARIANTS.items():
            new = NewAIME(**kw).create_explainer(X, Y, normalize=True)
            ref = RefAIME(**kw).create_explainer(X, Y, normalize=True)
            Xp = new.scaler.transform(X)

            # (A) new vs canonical reference — operator
            dA = float(np.max(np.abs(new.A_dagger - ref.A_dagger)))
            _chk(f"[A] {dname:>14} · {vname:<16} A† == reference", dA < ATOL,
                 f"max|Δ|={dA:.2e}")

            # (A) Bayesian posterior covariance
            if vname == "BayesianAIME":
                dC = float(np.max(np.abs(new.A_dagger_cov - ref.A_dagger_cov)))
                _chk(f"[A] {dname:>14} · {vname:<16} A†_cov == reference",
                     dC < ATOL, f"max|Δ|={dC:.2e}")

            # (B) operator vs closed-form paper formula
            pf = paper_operator(vname, Xp, Y)
            pf_op = pf[0] if isinstance(pf, tuple) else pf
            dP = float(np.max(np.abs(new.A_dagger - pf_op)))
            _chk(f"[B] {dname:>14} · {vname:<16} A† == paper formula", dP < ATOL,
                 f"max|Δ|={dP:.2e}")
            if isinstance(pf, tuple):
                dPC = float(np.max(np.abs(new.A_dagger_cov - pf[1])))
                _chk(f"[B] {dname:>14} · {vname:<16} A†_cov == paper formula",
                     dPC < ATOL, f"max|Δ|={dPC:.2e}")

            # (B) GLOBAL feature importance == peak-normalised columns of A†
            G = new.global_feature_importance_without_viz()
            ref_rows = []
            for t in range(new.A_dagger.shape[1]):
                col = new.A_dagger[:, t].copy()
                mx = np.max(np.abs(col))
                ref_rows.append(col / mx if mx > 0 else col)
            dG = float(np.max(np.abs(G.values - np.array(ref_rows))))
            _chk(f"[B] {dname:>14} · {vname:<16} global FI == norm. A† cols",
                 dG < ATOL, f"max|Δ|={dG:.2e}")

            # (B) LOCAL feature importance == normalised (A†y)⊙x'
            i = 3
            xi, yi = X[i], Y[i]
            L = new.local_feature_importance_without_viz(
                xi, yi, ignore_zero_features=False)   # paper rule, no masking
            heat = (new.A_dagger @ yi) * Xp[i]
            mx = np.max(np.abs(heat)); heat = heat / mx if mx > 0 else heat
            dL = float(np.max(np.abs(L.iloc[0].values - heat)))
            _chk(f"[B] {dname:>14} · {vname:<16} local FI == (A†y)⊙x' (norm)",
                 dL < ATOL, f"max|Δ|={dL:.2e}")

            # (B) masked local importance: absent (raw 0) features -> exactly 0
            if dname in ("multiclass(3)", "outliers(4)"):
                xz = X[i].copy(); xz[6] = 0.0
                Lm = new.local_feature_importance_without_viz(
                    xz, yi, feature_names=[f"f{j}" for j in range(len(xz))],
                    ignore_zero_features=True)
                z = float(Lm.get("f6").iloc[0]) if "f6" in Lm.columns else 0.0
                _chk(f"[B] {dname:>14} · {vname:<16} masked local: f6→0",
                     z == 0.0, f"f6={z:.2e}")

            # (B) REPRESENTATIVE instance == scaler⁻¹(A† eₜ)
            rep = new.representative_instance()
            m = new.A_dagger.shape[1]
            ref_rep = new.scaler.inverse_transform(new.A_dagger.T)  # rows = A† eₜ
            dR = float(np.max(np.abs(rep.values - ref_rep)))
            _chk(f"[B] {dname:>14} · {vname:<16} rep inst == scaler⁻¹(A†eₜ)",
                 dR < ATOL, f"max|Δ|={dR:.2e}")

    # RBF kernel identity (variant-independent)
    rng = np.random.default_rng(1)
    a = rng.normal(size=(5, 4)); b = rng.normal(size=(3, 4)); g = 0.37
    new = NewAIME().create_explainer(rng.normal(size=(20, 4)),
                                     _softmax(rng.normal(size=(20, 3))))
    K = new.rbf_kernel(a, b, g)
    Kref = np.exp(-g * ((a[:, None, :] - b[None, :, :]) ** 2).sum(-1))
    _chk("[B]  RBF kernel  exp(-γ‖·‖²) identity",
         np.max(np.abs(K - Kref)) < ATOL,
         f"max|Δ|={np.max(np.abs(K - Kref)):.2e}")


# --------------------------------------------------------------------------- #
# 4. pytest entry points (one assert per check) + standalone report.          #
# --------------------------------------------------------------------------- #
def test_paper_fidelity():
    run()
    failed = [(n, d) for n, ok, d in _results if not ok]
    assert not failed, "Fidelity failures:\n" + "\n".join(f"  {n} ({d})" for n, d in failed)


if __name__ == "__main__":
    run()
    npass = sum(1 for _, ok, _ in _results if ok)
    print("=" * 78)
    for name, ok, detail in _results:
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}   {detail}")
    print("=" * 78)
    print(f"{npass}/{len(_results)} fidelity checks passed")
    sys.exit(0 if npass == len(_results) else 1)
